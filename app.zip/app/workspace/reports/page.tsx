import { WorkspaceLayout } from "@/components/organism/workspace-layout";

export default function Reports() {
    return (
        <WorkspaceLayout>
            reports
        </WorkspaceLayout>
    );
}