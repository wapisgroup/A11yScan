import { WorkspaceLayout } from "../components/organism/workspace-layout";

export default function Workspace() {
    return (
        <WorkspaceLayout>
            Dashboard
        </WorkspaceLayout>
    );
}