import { WorkspaceLayout } from "@/components/organism/workspace-layout";

export default function Profile() {
    return (
        <WorkspaceLayout>
            Profile
        </WorkspaceLayout>
    );
}