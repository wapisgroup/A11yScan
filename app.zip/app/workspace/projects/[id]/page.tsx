"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";

import { WorkspaceLayout } from "@/components/organism/workspace-layout";
import { PageContainer } from "@/components/molecule/page-container";
import { startFullScan, startPageCollection } from "@/services/projectDetailService";

import { OverviewTab } from "@/components/tabs/project-detail-tab-overview";
import { RunsTab } from "@/components/tabs/project-detail-tab-runs";
import { SettingsTab } from "@/components/tabs/project-detail-tab-settings";
import { usePages, usePageSets, useProject, useRuns } from "@/state-services/project-detail-states";
import { Button } from "@/components/atom/button";
import { ProjectDetailStats } from "@/components/molecule/project-detail-stats";
import { ProjectStatsTDO, ProjectStatsWithCounts } from "@/tdo/project";
import { PageLike } from "@/tdo/page";
import { TabButton } from "@/components/atom/tab-button";
import { ProjectTabKey } from "@/types/project";
import { PageSetsTab } from "@/components/tabs/project-detail-tab-page-sets";
import { PagesTab } from "@/components/tabs/project-detail-tab-pages";



const HeaderButtons = ({ projectId }: { projectId: string }) => {
  return (
    <div className="flex gap-small">
      <Button title={`Collect pages`} variant="secondary" onClick={() => void startPageCollection(projectId)} />
      <Button title={`Start full scan`} variant="primary" onClick={() => void startFullScan(projectId)} />
    </div>
  );
};

export default function ProjectDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params?.id;
  const [tab, setTab] = useState<ProjectTabKey>("overview");
  const setTabSafe = (next: string) => {
    const allowed: ProjectTabKey[] = ["overview", "runs", "pages", "pageSets", "settings"];
    if ((allowed as string[]).includes(next)) {
      setTab(next as ProjectTabKey);
    }
  };
  const project = useProject(id);
  const runs = useRuns(id);
  const pages = usePages(id);
  const pageSets = usePageSets(id);

  // Derived stats
  const stats = useMemo<ProjectStatsWithCounts>(() => {
    const s: ProjectStatsTDO = { critical: 0, serious: 0, moderate: 0, minor: 0 };
    let scanned = 0;

    pages.forEach((p: PageLike) => {
      const c = p.violationsCount ?? {};

      s.critical += c.critical ?? 0;
      s.serious += c.serious ?? 0;
      s.moderate += c.moderate ?? 0;
      s.minor += c.minor ?? 0;

      if (p.status === "scanned") scanned++;
    });

    return { ...s, pagesTotal: pages.length, pagesScanned: scanned };
  }, [pages]);

  if (!id || !project) {
    return (
      <WorkspaceLayout>
        <PageContainer title="Project detail">
          <div className="secondary-text-color">Loading…</div>
        </PageContainer>
      </WorkspaceLayout>
    );
  }

  return (
    <WorkspaceLayout>
      <PageContainer excludePadding excludeHeaderBorder title={<> <h2 className="as-h3-text">{project?.name || 'Project'}</h2><div className="as-p3-text">{project?.domain}</div></>} buttons={<HeaderButtons projectId={id} />}>
        <div className="w-full">
          <div className="flex flex-col gap-medium">
            <div className="px-[var(--spacing-m)]"><ProjectDetailStats stats={stats} /></div>

            <div className="px-[var(--spacing-m)] py-[var(--spacing-m)] flex gap-small border-t border-b border-white/6">
              {(["overview", "runs", "pages", "pageSets", "settings"] as ProjectTabKey[]).map((t) => (
                <TabButton key={t} tabKey={t} onClick={setTab} selected={tab === t} />
              ))}
            </div>
          </div>

          <div className="bg-[#F5F7FB] px-[var(--spacing-m)] py-[var(--spacing-l)]  rounded-b-xl">
            {tab === "overview" && (
              <OverviewTab project={project} runs={runs} setTab={setTabSafe} />
            )}
            {tab === "runs" && <RunsTab project={project} runs={runs} />}
            {tab === "pages" && <PagesTab project={project} pages={pages} />}
            {tab === "pageSets" && (
              <PageSetsTab project={project} pages={pages} />
            )}
            {tab === "settings" && <SettingsTab project={project} />}
          </div>
        </div>
      </PageContainer>
    </WorkspaceLayout>
  );
}