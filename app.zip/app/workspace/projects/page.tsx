"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FiFileText, FiSettings, FiSlash, FiUpload } from "react-icons/fi";

import { PageContainer } from "@/components/molecule/page-container";
import { WorkspaceLayout } from "@/components/organism/workspace-layout";
import {
  createProject,
  deleteProject,
  loadProjects,
  startProjectScan,
  updateProject,
  type Project,
} from "@/services/projectsService";

import dynamic from "next/dynamic";
import { useConfirm } from "@/components/providers/confirm-provider";
import { Pagination } from "@/components/molecule/pagination";


const ProjectModal = dynamic(() => import("@/components/modals/ProjectModal"), {
  ssr: false,
  loading: () => null,
});

type ModalState =
  | { open: false }
  | { open: true; mode: "create"; initial?: null }
  | { open: true; mode: "edit"; initial: Project };

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  const [page, setPage] = useState<number>(1);
  const pageSize = 3;

  const [modal, setModal] = useState<ModalState>({ open: false });
  const openCreate = () => setModal({ open: true, mode: "create", initial: null });
  const openEdit = (p: Project) => setModal({ open: true, mode: "edit", initial: p });
  const closeModal = () => setModal({ open: false });
  const confirm = useConfirm();

  const refresh = async () => {
    setError("");
    setLoading(true);
    try {
      const list = await loadProjects();
      setProjects(list);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void refresh();
  }, []);

  useEffect(() => {
    const totalPages = Math.max(1, Math.ceil(projects.length / pageSize));
    if (page > totalPages) setPage(totalPages);
    if (page < 1) setPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projects.length]);

  const totalPages = Math.max(1, Math.ceil(projects.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const startIdx = (safePage - 1) * pageSize;
  const pagedProjects = projects.slice(startIdx, startIdx + pageSize);

  const start = async (p: Project) => {
    setError("");
    try {
      const runId = await startProjectScan({ id: p.id, domain: p.domain });
      // You can route to a run page later; for now, just confirm.
      // eslint-disable-next-line no-alert
      alert(`Scan started. Run ID: ${runId}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  const remove = async (p: Project) => {
    const ok =  await confirm({title: "Delete project", message: (<>Are you sure you want to delete{" "}<strong>{p.name || p.domain}</strong>?</>), confirmLabel: "Delete", cancelLabel: "Cancel", tone: "danger", });
    if (!ok) return;

    setError("");
    try {
      await deleteProject(p.id);
      await refresh();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  const AddButton = () => {
    return (
      <button
        type="button"
        onClick={openCreate}
        className="inline-flex items-center px-4 py-2 rounded-xl text-white bg-gradient-to-r from-purple-500 to-cyan-400"
        aria-label="Add project"
      >
        Add Project
      </button>
    );
  };

  return (
    <WorkspaceLayout>
      <PageContainer title="Projects" buttons={<AddButton />}>
        {error && <div className="text-red-600">{error}</div>}

        <div className="w-full">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="text-left as-p2-text table-heading-text-color font-bold">
                  <th className="py-4 pr-4">Project</th>
                  <th className="py-4 pr-4">URL</th>
                  <th className="py-4 pr-4">Last scan</th>
                  <th className="py-4 pr-4 text-right">&nbsp;</th>
                  <th className="py-4 pr-4 text-right">#</th>
                </tr>
              </thead>

              <tbody className="secondary-text-color as-p2-text">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="py-6 ">
                      Loading…
                    </td>
                  </tr>
                ) : pagedProjects.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 ">
                      No projects yet.
                    </td>
                  </tr>
                ) : (
                  pagedProjects.map((p) => {
                    const projectName = p.name || p.domain;
                    const url = p.domain?.startsWith("http") ? p.domain : `https://${p.domain}`;
                    // We only have createdAt in the current data model; show it as a placeholder for "Last scan".
                    const lastScan = p.createdAt
                      ? (() => {
                          try {
                            // Firestore Timestamp has toDate()
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            const v: any = p.createdAt;
                            const d: Date = typeof v?.toDate === "function" ? v.toDate() : new Date(v);
                            return d.toLocaleString();
                          } catch {
                            return "—";
                          }
                        })()
                      : "—";

                    return (
                      <tr key={p.id} className="border-t border-slate-100">
                        <td className="py-4 pr-4">
                          <Link
                            href={`/workspace/projects/${p.id}`}
                            className="text-slate-800 hover:underline"
                          >
                            {projectName}
                          </Link>
                        </td>

                        <td className="py-4 pr-4">
                          <a
                            href={url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-slate-700 hover:underline"
                          >
                            {url}
                          </a>
                        </td>

                        <td className="py-4 pr-4 text-slate-600">{lastScan}</td>

                        <td className="py-4">
                          <div className="flex justify-end gap-small">
                            <button
                              type="button"
                              onClick={() => void start(p)}
                              className="p-2 rounded hover:bg-slate-50"
                              aria-label="Start scan"
                              title="Start scan"
                            >
                              <FiUpload />
                            </button>

                            <Link
                              href={`/workspace/reports?projectId=${encodeURIComponent(p.id)}`}
                              className="p-2 rounded hover:bg-slate-50"
                              aria-label="View reports"
                              title="View reports"
                            >
                              <FiFileText />
                            </Link>

                            <button
                              type="button"
                              onClick={() => openEdit(p)}
                              className="p-2 rounded hover:bg-slate-50"
                              aria-label="Project settings"
                              title="Project settings"
                            >
                              <FiSettings />
                            </button>

                            <button
                              type="button"
                              onClick={() => void remove(p)}
                              className="p-2 rounded hover:bg-slate-50"
                              aria-label="Disable / delete"
                              title="Disable / delete"
                            >
                              <FiSlash />
                            </button>
                          </div>
                        </td>

                        <td className="py-4 text-right text-slate-400">&nbsp;</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-6">
            <Pagination
              page={safePage}
              totalPages={totalPages}
              onChange={(next) => setPage(next)}
            />
          </div>
        </div>

        <ProjectModal
          open={modal.open}
          mode={modal.open ? modal.mode : "create"}
          initial={modal.open ? modal.initial : null}
          onClose={closeModal}
          onSubmit={async (values: { name: string; domain: string }) => {
            setError("");
            try {
              if (!modal.open) return;

              if (modal.mode === "create") {
                await createProject({ name: values.name || undefined, domain: values.domain });
              } else {
                await updateProject({
                  id: modal.initial.id,
                  name: values.name || null,
                  domain: values.domain,
                });
              }

              closeModal();
              await refresh();
            } catch (err: unknown) {
              setError(err instanceof Error ? err.message : String(err));
            }
          }}
        />
      </PageContainer>
    </WorkspaceLayout>
  );
}