"use client";

import React, { createContext, useContext, useMemo, useState } from "react";
import { ConfirmDialog } from "@/components/molecule/confirm-dialog";
import { AlertDialog } from "@/components/molecule/alert-dialog";

type BaseDialogOptions = {
  title?: React.ReactNode;
  message: React.ReactNode;
  tone?: "default" | "danger";
};

type ConfirmOptions = BaseDialogOptions & {
  confirmLabel?: string;
  cancelLabel?: string;
};

type AlertOptions = BaseDialogOptions & {
  okLabel?: string;
};

type DialogMode = "confirm" | "alert";

type ConfirmContextValue = {
  confirm: (options: ConfirmOptions) => Promise<boolean>;
  alert: (options: AlertOptions) => Promise<void>;
};

const ConfirmContext = createContext<ConfirmContextValue | null>(null);

export function ConfirmProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<DialogMode>("confirm");
  const [options, setOptions] = useState<ConfirmOptions | AlertOptions | null>(
    null
  );
  const [resolver, setResolver] =
    useState<((v: boolean | void) => void) | null>(null);

  const confirm = (opts: ConfirmOptions) =>
    new Promise<boolean>((resolve) => {
      setMode("confirm");
      setOptions(opts);
      setResolver(() => resolve);
      setOpen(true);
    });

  const alert = (opts: AlertOptions) =>
    new Promise<void>((resolve) => {
      setMode("alert");
      setOptions(opts);
      setResolver(() => resolve);
      setOpen(true);
    });

  const close = (result?: boolean) => {
    setOpen(false);
    resolver?.(result);
    setResolver(null);
    setOptions(null);
  };

  const value = useMemo(() => ({ confirm, alert }), []);

  return (
    <ConfirmContext.Provider value={value}>
      {children}

      {/* Confirm dialog */}
      {mode === "confirm" && (
        <ConfirmDialog
          open={open}
          title={options?.title ?? "Confirm"}
          message={options?.message ?? ""}
          confirmLabel={(options as ConfirmOptions | null)?.confirmLabel}
          cancelLabel={(options as ConfirmOptions | null)?.cancelLabel}
          tone={options?.tone}
          onCancel={() => close(false)}
          onConfirm={() => close(true)}
        />
      )}

      {/* Alert dialog */}
      {mode === "alert" && (
        <AlertDialog
          open={open}
          title={options?.title ?? "Alert"}
          message={options?.message ?? ""}
          okLabel={(options as AlertOptions | null)?.okLabel}
          tone={options?.tone}
          onOk={() => close()}
        />
      )}
    </ConfirmContext.Provider>
  );
}

export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx)
    throw new Error("useConfirm must be used within <ConfirmProvider>");
  return ctx.confirm;
}

export function useAlert() {
  const ctx = useContext(ConfirmContext);
  if (!ctx)
    throw new Error("useAlert must be used within <ConfirmProvider>");
  return ctx.alert;
}