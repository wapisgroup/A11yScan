"use client";

import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import type { Project } from "@/services/projectsService";
import { Popup } from "../molecule/popup";

type Mode = "create" | "edit";

type Props = {
  mode: Mode;
  open: boolean;
  initial?: Partial<Project> | null;
  onClose: () => void;
  onSubmit: (values: { name: string; domain: string }) => Promise<void> | void;
};

export default function ProjectModal({ mode, open, initial, onClose, onSubmit }: Props) {
  const [mounted, setMounted] = useState(false);
  const [name, setName] = useState(initial?.name ?? "");
  const [domain, setDomain] = useState(initial?.domain ?? "");

  useEffect(() => setMounted(true), []);

  // keep fields in sync when switching between edit targets
  useEffect(() => {
    setName(initial?.name ?? "");
    setDomain(initial?.domain ?? "");
  }, [initial?.name, initial?.domain, open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const title = mode === "create" ? "New project" : "Edit project";

  const body = open ? (
   
        <Popup title={title}>
          <p className="secondary-text-color">
            Cras erat libero, sodales sit amet enim sit amet, luctus luctus nisl...
          </p>

          <input
            className="w-full input"
            placeholder="Name (optional)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />

          <input
            className="w-full input"
            placeholder="URL address"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
          />

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              className="px-5 py-2 rounded-xl border border-slate-200"
              onClick={onClose}
            >
              Cancel
            </button>

            <button
              type="button"
              className="px-5 py-2 rounded-xl text-white bg-gradient-to-r from-purple-500 to-cyan-400"
              onClick={() => onSubmit({ name, domain })}
            >
              {mode === "create" ? "Create" : "Save"}
            </button>
          </div>
        </Popup>
  ) : null;

  if (!mounted) return null;
  return createPortal(body, document.body);
}