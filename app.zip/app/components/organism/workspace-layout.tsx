"use client";

import React, { type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

import Header from "@/components/molecule/header";
import {
  URL_APP_DASHBOARD,
  URL_APP_PROJECTS,
  URL_APP_REPORTS,
} from "@/utils/urls";
import { PiCirclesFourLight, PiFolderOpenLight, PiNotepadLight } from "react-icons/pi";

type WorkspaceLayoutProps = {
  children: ReactNode;
};

export function WorkspaceLayout({ children }: WorkspaceLayoutProps) {
  const navItems = [
    { href: URL_APP_DASHBOARD, label: "Dashboard", icon: <PiCirclesFourLight /> },
    { href: URL_APP_PROJECTS, label: "Projects", icon: <PiFolderOpenLight /> },
    { href: URL_APP_REPORTS, label: "Reports", icon: <PiNotepadLight /> },
  ];

  const pathname = usePathname();

  return (
    <div className="min-h-screen">
      <Header />

      <div className="min-h-screen grid grid-cols-[211px_auto]">

        <div className="py-[var(--spacing-l)] bg-[#EEF0F5] border-r border-[#E3E7EF]">
          <nav className="flex flex-col gap-8">
            <ul className="flex flex-col">
              {navItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={
                      `as-p2-text p-[var(--spacing-s)] block pl-[20px] border-l-4 ` +
                      (pathname === item.href
                        ? "bg-[#5483E7]/15 text-[#649DAD] border-[#649DAD]"
                        : "text-[#71737D] hover:bg-[#5483E7]/10 hover:border-[#649DAD]/30")
                    }
                  >
                    <span className="inline-flex items-center gap-2">
                      <span
                        className={
                          `inline-flex h-5 w-5 items-center justify-center text-[20px] ` +
                          (pathname === item.href ? "text-[#0EA5A4]" : "text-[#9CA3AF]")
                        } 
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        <div className="flex flex-col gap-x-2 bg-gradient-to-b from-[#F8FAFC] via-[#F1F5F9] to-[#FFFFFF]">
          <main className="px-6 pt-6">{children}</main>
        </div>
      </div>
    </div>
  );
}