"use client";

import React, { useCallback, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { callServerFunction } from "@/services/serverService";
import { scanSinglePage } from "@/services/projectDetailService";
import { PageRow } from "../molecule/project-detail-page-row";
import { PageContainer } from "../molecule/page-container";
import { Button } from "../atom/button";
import { Checkbox } from "../atom/checkbox";
import { useAlert } from "../providers/confirm-provider";

type Project = {
  id: string;
  [key: string]: unknown;
};

type Page = {
  id: string;
  url?: string | null;
  title?: string | null;
  artifactUrl?: string | null;
  [key: string]: unknown;
};

type PagesTabProps = {
  project: Project;
  pages: Page[];
};

type PageListRowProps = {
  projectId: string;
  page: Page;
  checked: boolean;
  onToggle: (pageId: string, checked: boolean) => void;
  onScan: (page: Page) => void;
  onOpen: (page: Page) => void;
};

const PageListRow = React.memo(function PageListRow({
  projectId,
  page,
  checked,
  onToggle,
  onScan,
  onOpen,
}: PageListRowProps) {
  return (
    <div className="flex items-center gap-large">
      <Checkbox
        checked={checked}
        onChange={(e) => onToggle(page.id, !!e.target?.checked)}
      />

      <div className="flex-1">
        <PageRow
          projectId={projectId}
          page={page}
          onScan={() => onScan(page)}
          onOpen={() => onOpen(page)}
        />
      </div>
    </div>
  );
});

export function PagesTab({ project, pages }: PagesTabProps) {
  const router = useRouter();
  const [filterText, setFilterText] = useState<string>("");
  const [selectedPages, setSelectedPages] = useState<Set<string>>(() => new Set());
  const selectedCount = selectedPages.size;

  const alert = useAlert();



  const projectId = project?.id;

  const togglePage = useCallback((pageId: string, checked: boolean) => {
    setSelectedPages((prev) => {
      const next = new Set(prev);
      if (checked) next.add(pageId);
      else next.delete(pageId);
      return next;
    });
  }, []);

  const scanPage = useCallback(
    (page: Page) => {
      if (!projectId) return;
      void scanSinglePage(projectId, page);
    },
    [projectId]
  );

  const openReport = useCallback(
    (page: Page) => {
      if (!projectId) return;
      if (page?.artifactUrl) {
        window.open(page.artifactUrl, "_blank", "noopener,noreferrer");
        return;
      }
      router.push(`/workspace/projects/${projectId}/page-report/${page.id}`);
    },
    [projectId, router]
  );

  /* UI helpers */
  const filteredPages = useMemo(() => {
    if (!filterText) return pages;
    const t = filterText.toLowerCase();
    return pages.filter((p) =>
      ((p.url || "").toLowerCase().includes(t) || (p.title || "").toLowerCase().includes(t))
    );
  }, [pages, filterText]);

  async function runSelectedPages() {
    if (!projectId) return;

    if (selectedCount === 0) {
      // eslint-disable-next-line no-alert
      await alert({
        title: "System exceptaion",
        message: "No pages selected",
      });
      return;
    }

    const pageIds = Array.from(selectedPages);

    try {
      const payload = { projectId, type: "page-list-scan", pageIds };
      await callServerFunction("startScan", payload);
      // eslint-disable-next-line no-alert
      await alert({
        title: "Information",
        message: "Scan for selected pages started",
      });
      setSelectedPages(new Set());
    } catch (err: unknown) {
      // eslint-disable-next-line no-console
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err);
      // eslint-disable-next-line no-alert

      await alert({
        title: "System exceptaion",
        message: "Failed to start pages scan: " + msg,
      });
    }
  }

  if (!projectId) return <div>Loading</div>;

  return (
    <PageContainer inner>
      <div className="flex flex-col gap-medium w-full p-[var(--spacing-m)]">
        <div className="flex items-center justify-between border-b border-solid border-white/6 pb-[var(--spacing-m)]">
          <div className="flex gap-small items-center">
            <input
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder="Filter pages by url or title"
              className="input"
            />

            <Button
              variant="secondary"
              onClick={() => setSelectedPages(new Set())}
              title={`Clear selection`}
            />

            <Button
              variant="primary"
              onClick={() => void runSelectedPages()}
              title={`${selectedCount > 0 ? `Scan selected (${selectedCount})` : `Scan all`}`}
            />
          </div>

          <div className="as-p2-text secondary-text-color">{filteredPages.length} pages</div>
        </div>

        <div className="w-full flex flex-col gap-large py-[var(--spacing-m)]">
          {filteredPages.map((p) => (
            <PageListRow
              key={p.id}
              projectId={projectId}
              page={p}
              checked={selectedPages.has(p.id)}
              onToggle={togglePage}
              onScan={scanPage}
              onOpen={openReport}
            />
          ))}

          {filteredPages.length === 0 && <div className="text-slate-400">No pages found</div>}
        </div>
      </div>
    </PageContainer>

  );
}