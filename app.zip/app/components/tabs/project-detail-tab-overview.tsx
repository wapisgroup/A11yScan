"use client";

import React from "react";
import Link from "next/link";

import {
  startFullScan,
  startPageCollection,
  startSitemap,
} from "@/services/projectDetailService";
import { RunRow } from "../molecule/project-detail-run-row";
import { PageContainer } from "../molecule/page-container";
import { Button } from "../atom/button";

type Run = {
  id: string;
  // add more fields if needed by RunRow
  [key: string]: unknown;
};

type Project = {
  id: string;
  sitemapTreeUrl?: string | null;
  [key: string]: unknown;
};

type OverviewTabProps = {
  project?: Project | null;
  runs?: Run[];
  setTab: (tab: "overview" | "runs" | string) => void;
};

export function OverviewTab({ project, runs = [], setTab }: OverviewTabProps) {
  const projectId = project?.id;

  if (!projectId) return <div>Loading</div>;

  return (
    <div className="space-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        <PageContainer title={`Sitemap`} inner>
          <div>
            {project?.sitemapTreeUrl ? (
              <div className="flex flex-col items-center gap-large">
                <p className="as-p2-text secondary-text-color text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tempus justo orci, semper lobortis nibh ullamcorper ac. Sed leo ex, elementum maximus aliquet ac</p>
                <div className="flex flex-col gap-medium">
                  <a
                    href={project.sitemapTreeUrl}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Button variant="secondary" title={`Download sitemap.xml`} />

                  </a>

                  <a href={`/workspace/sitemap/${projectId}`} className="text-center">
                    <Button variant="link" title={`Show diagram`} />
                  </a>
                </div>


              </div>
            ) : (
              <>
                <div className="text-slate-400">No sitemap generated yet.</div>
                <button
                  type="button"
                  onClick={() => void startSitemap(projectId)}
                  className="px-2 py-1 text-white rounded"
                >
                  Generate sitemap
                </button>
              </>
            )}
          </div>
        </PageContainer>

        <PageContainer title={`Latest tasks`} inner>
          <div className="flex flex-col gap-small">
            {runs.slice(0, 4).map((r) => (
              <RunRow key={r.id} run={r} onView={() => setTab("runs")} />
            ))}
            {runs.length === 0 && <div className="as-p2-text secondary-text-color">No runs yet</div>}
          </div>
        </PageContainer>

        <PageContainer title={`Quick actions`} inner>
          <div className="flex flex-col items-center gap-large">
            <p className="as-p2-text secondary-text-color text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tempus justo orci, semper lobortis nibh ullamcorper ac. Sed leo ex, elementum maximus aliquet ac</p>
            <div className="flex flex-col gap-medium">
              <Button
                variant="secondary"
                title="Generate sitemap"
                onClick={() => void startPageCollection(projectId)}
              />

              <Button
                variant="primary"
                title="Start full scan"
                onClick={() => void startFullScan(projectId)}
              />
            </div>
          </div>
        </PageContainer>
      </div>
    </div>
  );
}