"use client";

import React, { useMemo, useState } from "react";
import { doc, updateDoc } from "firebase/firestore";

import { db } from "@/utils/firebase";

type ProjectConfig = {
  maxPages?: number;
  crawlDelayMs?: number;
  robotsRespect?: boolean;
  storeArtifacts?: boolean;
};

type Project = {
  id: string;
  config?: ProjectConfig;
};

type SettingsTabProps = {
  project?: Project | null;
};

export function SettingsTab({ project }: SettingsTabProps) {
  const projectId = project?.id;
  const config = project?.config;

  const [status, setStatus] = useState<{ kind: "idle" | "ok" | "error"; message?: string }>({
    kind: "idle",
  });

  const defaults = useMemo(
    () => ({
      maxPages: config?.maxPages ?? 1000,
      crawlDelayMs: config?.crawlDelayMs ?? 100,
      robotsRespect: config?.robotsRespect ?? true,
      storeArtifacts: config?.storeArtifacts ?? true,
    }),
    [config]
  );

  async function updateProjectConfig(updated: Partial<ProjectConfig>) {
    if (!projectId) return;

    setStatus({ kind: "idle" });

    try {
      const pRef = doc(db, "projects", projectId);
      await updateDoc(pRef, { config: { ...(config || {}), ...updated } });
      setStatus({ kind: "ok", message: "Saved" });
    } catch (err: unknown) {
      // eslint-disable-next-line no-console
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err);
      setStatus({ kind: "error", message: "Save failed: " + msg });
    }
  }

  if (!projectId) return <div>Loading</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Settings</h3>

        {status.kind !== "idle" && (
          <div
            className={
              "text-sm " +
              (status.kind === "ok" ? "text-emerald-400" : "text-red-400")
            }
            role={status.kind === "error" ? "alert" : "status"}
          >
            {status.message}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white/3 p-4 rounded border border-white/6">
          <label className="text-sm text-slate-300">Max pages</label>
          <input
            type="number"
            defaultValue={defaults.maxPages}
            onBlur={(e) => void updateProjectConfig({ maxPages: Number(e.target.value) })}
            className="mt-2 w-full px-3 py-2 rounded bg-white/5 border border-white/6"
          />

          <label className="text-sm text-slate-300 mt-3 block">Crawl delay (ms)</label>
          <input
            type="number"
            defaultValue={defaults.crawlDelayMs}
            onBlur={(e) => void updateProjectConfig({ crawlDelayMs: Number(e.target.value) })}
            className="mt-2 w-full px-3 py-2 rounded bg-white/5 border border-white/6"
          />
        </div>

        <div className="bg-white/3 p-4 rounded border border-white/6">
          <label className="text-sm text-slate-300">Respect robots.txt</label>
          <div className="mt-2">
            <button
              type="button"
              onClick={() => void updateProjectConfig({ robotsRespect: true })}
              className={
                "px-3 py-1 rounded " +
                (defaults.robotsRespect
                  ? "bg-cyan-400 text-slate-900"
                  : "bg-white/5")
              }
            >
              On
            </button>
            <button
              type="button"
              onClick={() => void updateProjectConfig({ robotsRespect: false })}
              className={
                "px-3 py-1 rounded ml-2 " +
                (defaults.robotsRespect === false
                  ? "bg-cyan-400 text-slate-900"
                  : "bg-white/5")
              }
            >
              Off
            </button>
          </div>

          <label className="text-sm text-slate-300 mt-4 block">
            Store artifacts (screenshots &amp; HTML)
          </label>
          <div className="mt-2">
            <button
              type="button"
              onClick={() => void updateProjectConfig({ storeArtifacts: true })}
              className={
                "px-3 py-1 rounded " +
                (defaults.storeArtifacts
                  ? "bg-cyan-400 text-slate-900"
                  : "bg-white/5")
              }
            >
              On
            </button>
            <button
              type="button"
              onClick={() => void updateProjectConfig({ storeArtifacts: false })}
              className={
                "px-3 py-1 rounded ml-2 " +
                (defaults.storeArtifacts === false
                  ? "bg-cyan-400 text-slate-900"
                  : "bg-white/5")
              }
            >
              Off
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}