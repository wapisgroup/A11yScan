"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { RunRow } from "../molecule/project-detail-run-row";
import { PageContainer } from "../molecule/page-container";

type Project = {
  id: string;
  [key: string]: unknown;
};

type Run = {
  id: string;
  [key: string]: unknown;
};

type RunsTabProps = {
  project: Project;
  runs: Run[];
};

export function RunsTab({ project, runs }: RunsTabProps) {
  const router = useRouter();
  const projectId = project?.id;

  if (!projectId) return <div>Loading</div>;

  return (
    <div className="space-y-4">
      <PageContainer title={`Tasks`} inner>
        {runs.length === 0 ? (
          <div className="text-slate-400">No runs yet</div>
        ) : (
          <div className="space-y-3">
            {runs.map((r) => (
              <RunRow
                key={r.id}
                run={r}
                onView={(run: Run) => router.push(`/workspace/projects/${projectId}/runs/${run.id}`)}
              />
            ))}
          </div>
        )}
      </PageContainer>

    </div>
  );
}