"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { PageSetRow } from "@/components/molecule/project-detail-page-set-row";
import { PageContainer } from "@/components/molecule/page-container";
import { Button } from "@/components/atom/button";
import { useAlert, useConfirm } from "@/components/providers/confirm-provider";
import { callServerFunction } from "@/services/serverService";
import { createPageSet as createPageSetService, deletePageSet, loadPageSets } from "@/services/projectSetsService";

type Project = {
  id: string;
};

type Page = {
  id: string;
  url: string;
};

type PageSet = {
  id: string;
  name: string;
  // add other fields if your row expects them
  [key: string]: unknown;
};

type PageSetsTabProps = {
  project: Project;
  pages: Page[];

};

export function PageSetsTab({ project, pages}: PageSetsTabProps) {
  const router = useRouter();
  const projectId = project?.id;

  const [newSetName, setNewSetName] = useState<string>("");
  const [newSetRegex, setNewSetRegex] = useState<string>("");
  const [filterText, setFilterText] = useState<string>("");
  const [creatingSet, setCreatingSet] = useState<boolean>(false);

  const [pageSets, setPageSets] = useState<PageSet[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  const canCreate = useMemo(() => !!projectId && !!newSetName.trim() && !creatingSet, [projectId, newSetName, creatingSet]);

  const alert = useAlert();
  const confirm = useConfirm();

  const refresh = async () => {
    setError("");
    setLoading(true);
    try {
      const list = await loadPageSets();
      setPageSets(list.filter((s) => s.projectId === projectId));
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!projectId) return;
    void refresh();
  }, [projectId]);

  const runPageset = useCallback(async (setDoc: PageSet) => {
    if (!projectId || !setDoc) return;
    try {
      const payload = { projectId, type: "pageset-scan", pagesetId: setDoc.id };
      await callServerFunction("startScan", payload);
      await alert({
        title: "System information",
        message: "Scan for page set queued",
      });
    } catch (err: unknown) {
      // eslint-disable-next-line no-console
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err);
      await alert({
        title: "System exception",
        message: "Failed to start page set scan: " + msg,
      });
    }
  }, [alert, projectId]);

  const handleCreatePageSet = useCallback(async () => {
    if (!projectId) return;
    if (!newSetName.trim()) {
      await alert({
        title: "System exception",
        message: "Give the page set a name",
      });
      return;
    }

    setCreatingSet(true);
    try {
      const filterSpec: { regex: string | null; excludePatterns: string[] } = {
        regex: newSetRegex.trim() ? newSetRegex.trim() : null,
        excludePatterns: [],
      };

      // Compute matched pages (client-side)
      let matched: string[] = [];
      if (filterSpec.regex) {
        let re: RegExp;
        try {
          re = new RegExp(filterSpec.regex);
        } catch (e: unknown) {
          const msg = e instanceof Error ? e.message : String(e);
          await alert({
            title: "System exception",
            message: "Invalid regex: " + msg,
          });
          return;
        }
        matched = pages.filter((p) => re.test(p.url)).map((p) => p.id);
      } else if (filterText.trim()) {
        const t = filterText.trim().toLowerCase();
        matched = pages.filter((p) => p.url.toLowerCase().includes(t)).map((p) => p.id);
      } else {
        matched = pages.map((p) => p.id);
      }

      await createPageSetService({
        object: {
          projectId,
          name: newSetName.trim(),
          filterSpec: JSON.stringify(filterSpec),
          pageIds: matched,
        },
      });

      await refresh();

      setNewSetName("");
      setNewSetRegex("");
      setFilterText("");
      await alert({
        title: "System information",
        message: "Page set created",
      });
    } catch (err: unknown) {
      // eslint-disable-next-line no-console
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err);
      await alert({
        title: "System exception",
        message: "Failed to create page set: " + msg,
      });

    } finally {
      setCreatingSet(false);
    }
  }, [alert, filterText, newSetName, newSetRegex, pages, projectId]);

  const handleDelete = useCallback(
    async (setDoc: PageSet) => {
      if (!projectId) return;

      const ok = await confirm({
        title: "Delete page set",
        message: (
          <>
            Delete page set <strong className="ml-1">{setDoc.name}</strong>?
          </>
        ),
        confirmLabel: "Delete",
        cancelLabel: "Cancel",
        tone: "danger",
      });

      if (!ok) return;

      try {
        if (!setDoc?.id) throw new Error("Missing page set id");

        await deletePageSet(setDoc.id);
        await alert({
          title: "System information",
          message: "Page set has been deleted",
        });
        await refresh();
      } catch (err: unknown) {
        // eslint-disable-next-line no-console
        console.error(err);
        const msg = err instanceof Error ? err.message : String(err);
        await alert({
          title: "System exception",
          message: "Failed to delete: " + msg,
        });
      }
    },
    [alert, confirm, projectId]
  );

  if (!projectId) return <div>Loading</div>;

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-medium">
        <PageContainer inner title={`Create new set`}>

          <div className="flex flex-col gap-medium w-full">
            <div className="flex flex-col gap-small">
              <input
                value={newSetName}
                onChange={(e) => setNewSetName(e.target.value)}
                placeholder="Set name"
                className="input"
              />

              <input
                value={newSetRegex}
                onChange={(e) => setNewSetRegex(e.target.value)}
                placeholder="Regex (optional)"
                className="input"
              />

              <input
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder="URL contains (optional)"
                className="input"
              />
            </div>

            <div className="flex gap-small">
              <Button
                variant="secondary"
                onClick={() => {
                  setNewSetName("");
                  setNewSetRegex("");
                  setFilterText("");
                }}
                title={`Clear`}
              />

              <Button
                variant="primary"
                onClick={() => void handleCreatePageSet()}
                disabled={!canCreate || loading}
                title={`Create`}
              />



            </div>
          </div>
        </PageContainer>

        <PageContainer inner title={`Page sets`}>
          <div className="md:col-span-2 space-y-2">
            {loading && (
              <div className="text-slate-400 p-3 bg-white/3 rounded border border-white/6">
                Loading page sets…
              </div>
            )}

            {!loading && error && (
              <div className="text-red-300 p-3 bg-white/3 rounded border border-white/6">
                {error}
              </div>
            )}

            {!loading && !error &&
              pageSets.map((s) => (
                <PageSetRow
                  key={s.id}
                  setDoc={s}
                  onRun={runPageset}
                  onEdit={(sdoc: PageSet) => router.push(`/workspace/projects/${projectId}/pageSets/${sdoc.id}/edit`)}
                  onDelete={handleDelete}
                />
              ))}

            {!loading && !error && pageSets.length === 0 && (
              <div className="text-slate-400 p-3 bg-white/3 rounded border border-white/6">
                No page sets created yet.
              </div>
            )}
          </div>
        </PageContainer>
      </div>
    </div>
  );
}