"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  collection,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
  type DocumentData,
  type Unsubscribe,
} from "firebase/firestore";

import { db } from "@/utils/firebase";
import { PiInfo, PiInfoLight } from "react-icons/pi";
import { Button } from "../atom/button";
import { ProjectInfoLine } from "../atom/project-info-line";
import { normalizeStatus, safeNumber, statusFromRun } from "@/ui-helpers/page";
import { PageDoc } from "@/tdo/page";
import { PageStatsTDO } from "@/tdo/project";



type RunDoc = {
  id: string;
  status?: string | null;
  startedAt?: unknown;
  // other fields ignored
};


type PageRowProps = {
  projectId: string;
  page: PageDoc;
  onScan?: () => void;
  onOpen?: () => void;
};

export function PageRow({ projectId, page, onScan, onOpen }: PageRowProps) {
  const [referencingRun, setReferencingRun] = useState<RunDoc | null>(null);


  // Subscribe to the most-recent run that references this page
  useEffect(() => {
    let unsub: Unsubscribe | null = null;

    if (!projectId || !page?.id) {
      setReferencingRun(null);
      return;
    }

    const runsCol = collection(db, "projects", projectId, "runs");
    const runsQuery = query(
      runsCol,
      where("pagesIds", "array-contains", page.id),
      orderBy("startedAt", "desc"),
      limit(1)
    );

    unsub = onSnapshot(
      runsQuery,
      (snap) => {
        if (!snap.docs.length) {
          setReferencingRun(null);
          return;
        }

        const d = snap.docs[0];
        const data = d.data() as DocumentData;
        setReferencingRun({ id: d.id, status: data?.status ?? null, startedAt: data?.startedAt });
      },
      (err) => {
        // eslint-disable-next-line no-console
        console.warn("PageRow: runs onSnapshot error", err);
        setReferencingRun(null);
      }
    );

    return () => {
      try {
        unsub?.();
      } catch {
        // ignore
      }
    };
  }, [projectId, page.id]);

  // Use page-level stats when available
  const counts = useMemo(() => {
    const summary = (page.lastStats ?? null) as PageStatsTDO | null;
    return {
      critical: safeNumber(summary?.critical),
      serious: safeNumber(summary?.serious),
      moderate: safeNumber(summary?.moderate),
      minor: safeNumber(summary?.minor),
    };
  }, [page.lastStats]);

  const totalIssues = counts.critical + counts.serious + counts.moderate + counts.minor;

  // Status determination prefers explicit page.status -> run status -> discovered
  const status = useMemo(() => {
    const pageStatus = normalizeStatus(page.status);
    if (page.status) return pageStatus;
    return statusFromRun(referencingRun);
  }, [page.status, referencingRun]);

  const lastRunId = page.lastRunId || referencingRun?.id || null;
  const hasScan = Boolean(page.lastScan || page.lastRunId || referencingRun?.id);


  return (
    <div className="flex items-center justify-between gap-small relative">
      <div className="flex flex-col gap-[12px]">
        <div className="flex flex-col gap-[0px]">
          {/* Url line */}
          <div className="flex gap-[10px]">
            <span className="as-h5-text font-medium truncate max-w-[700px]" title={`URL: ${page.url}`}>{page.url}</span>
            {lastRunId && (
              <div className="as-p3-text table-heading-text-color">
                run: {String(lastRunId).slice(0, 8)}
              </div>
            )}
          </div>
          {/* Description line */}
          <div className="as-p3-text secondary-text-color">{page.title || ""}</div>
        </div>
        {/* Info line */}
        <ProjectInfoLine totalIssues={totalIssues} status={status} page={page} />

      </div>
      <div className="flex gap-medium">
        <Button title={hasScan ? "Re-scan" : "Scan"} variant="secondary" onClick={() => onScan?.()} />
        <Button variant="secondary" onClick={() => onOpen?.()} title={`Report`} />
      </div>
    </div>
  );
}