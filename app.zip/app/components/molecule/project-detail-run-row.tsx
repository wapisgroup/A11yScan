"use client";

import React, { useMemo } from "react";

type TimestampLike = {
  toDate?: () => Date;
};

type RunDoc = {
  id: string;
  type?: string | null;
  status?: string | null;
  startedAt?: unknown;
  pagesTotal?: number | null;
  pagesScanned?: number | null;
  [key: string]: unknown;
};

type RunRowProps = {
  run: RunDoc;
  onView: (run: RunDoc) => void;
};

function toDateSafe(v: unknown): Date {
  if (!v) return new Date();

  // Firestore Timestamp
  const ts = v as TimestampLike;
  if (typeof ts?.toDate === "function") {
    try {
      return ts.toDate();
    } catch {
      return new Date();
    }
  }

  // epoch ms / ISO
  const d = new Date(v as any);
  return Number.isNaN(d.getTime()) ? new Date() : d;
}

function safeInt(n: unknown): number {
  const v = Number(n);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.floor(v));
}

export function RunRow({ run, onView }: RunRowProps) {
  const pagesTotal = safeInt(run.pagesTotal);
  const pagesScanned = safeInt(run.pagesScanned);

  const progress = useMemo(() => {
    if (pagesTotal > 0) {
      return Math.max(0, Math.min(100, Math.round((pagesScanned / pagesTotal) * 100)));
    }

    const status = String(run.status ?? "").toLowerCase();
    if (["done", "finished", "completed", "success"].includes(status)) return 100;
    if (["queued", "running", "pending"].includes(status)) return 1;
    return 0;
  }, [pagesScanned, pagesTotal, run.status]);

  const startedLabel = useMemo(() => {
    const d = toDateSafe(run.startedAt);
    return d.toLocaleString();
  }, [run.startedAt]);

  const typeLabel = (run.type ?? "scan") as string;
  const statusLabel = (run.status ?? "-") as string;

  return (
    <div className="flex items-center justify-between gap-4 p-3 bg-white/2 rounded-md border border-white/6">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-3">
          <div className="font-medium truncate">
            {typeLabel} · {startedLabel}
          </div>
          <div className="text-xs text-slate-300">status: {statusLabel}</div>
        </div>

        <div className="mt-2 h-2 bg-white/6 rounded-md overflow-hidden">
          <div
            className="h-2 bg-gradient-to-r from-purple-500 to-cyan-400"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="text-xs text-slate-400 mt-1">
          {pagesScanned}/{pagesTotal} pages · {progress}%
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          className="px-3 py-1 rounded bg-white/5"
          onClick={() => onView(run)}
        >
          View
        </button>
      </div>
    </div>
  );
}