import { auth, db } from "@/utils/firebase";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";

type PageSet = {
  projectId: string;
  name: string;
  filterSpec: string;
  pageIds: string[];
};

type PageSetPayload = PageSet & {
  owner: string | null;
  createdAt: ReturnType<typeof serverTimestamp>;
};

type PageSetDoc = PageSetPayload & {
  id: string;
};

type CreatePageSetProps = {
  object: PageSet;
};

export const createPageSet = async ({ object }: CreatePageSetProps): Promise<PageSetDoc> => {
  const { name } = object;
  if (!name) throw new Error("name required");

  const payload: PageSetPayload = {
    ...object,
    owner: auth.currentUser ? auth.currentUser.uid : null,
    createdAt: serverTimestamp(),
  };

  const ref = await addDoc(collection(db, "pageSets"), payload);

  return {
    id: ref.id,
    ...payload,
  };
};


export async function loadPageSets(): Promise<PageSetDoc[]> {
  const q = query(collection(db, "pageSets"), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);

  return snap.docs.map((d) => {
    const data = d.data() as Record<string, unknown>;

    const pageIdsRaw = data.pageIds;
    const pageIds = Array.isArray(pageIdsRaw) ? pageIdsRaw.map((v) => String(v)) : [];

    return {
      id: d.id,
      projectId: String(data.projectId ?? ""),
      name: String(data.name ?? ""),
      filterSpec: String(data.filterSpec ?? ""),
      pageIds,
      owner: (data.owner ?? null) as string | null,
      // Firestore returns a Timestamp here; keep it flexible.
      createdAt: data.createdAt as PageSetDoc["createdAt"],
    };
  });
}

export async function deletePageSet(id: string): Promise<void> {
  if (!id) throw new Error("id required");
  await deleteDoc(doc(db, "pageSets", id));
}