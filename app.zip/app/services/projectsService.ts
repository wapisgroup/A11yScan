
// src/services/projectsService.js
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  type DocumentData,
  type Timestamp,
} from "firebase/firestore";

import { auth, db, startScan } from "@/utils/firebase";

export type Project = {
  id: string;
  name: string | null;
  domain: string;
  owner: string | null;
  createdAt?: Timestamp | Date | null;
};

export type CreateProjectInput = {
  name?: string;
  domain: string;
};

export type UpdateProjectInput = {
  id: string;
  name: string | null;
  domain: string;
};

export async function loadProjects(): Promise<Project[]> {
  const q = query(collection(db, "projects"), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);

  return snap.docs.map((d) => {
    const data = d.data() as DocumentData;
    return {
      id: d.id,
      name: (data.name ?? null) as string | null,
      domain: String(data.domain ?? ""),
      owner: (data.owner ?? null) as string | null,
      createdAt: (data.createdAt ?? null) as Timestamp | Date | null,
    };
  });
}

export async function createProject({ name, domain }: CreateProjectInput): Promise<Project> {
  if (!domain) throw new Error("domain required");

  const payload = {
    name: name ?? null,
    domain,
    owner: auth.currentUser ? auth.currentUser.uid : null,
    createdAt: serverTimestamp(),
  };

  const ref = await addDoc(collection(db, "projects"), payload);

  return {
    id: ref.id,
    name: payload.name,
    domain: payload.domain,
    owner: payload.owner,
    // serverTimestamp() resolves on the server; keep it null/undefined in the returned object
    createdAt: null,
  };
}

export async function updateProject(project: UpdateProjectInput): Promise<void> {
  if (!project?.id) throw new Error("project.id required");

  await updateDoc(doc(db, "projects", project.id), {
    name: project.name ?? null,
    domain: project.domain,
  });
}

export async function deleteProject(id: string): Promise<void> {
  if (!id) throw new Error("id required");
  await deleteDoc(doc(db, "projects", id));
}

export async function startProjectScan(project: Pick<Project, "id" | "domain">): Promise<string> {
  if (!project?.id) throw new Error("project.id required");

  // Delegate to firebase utils startScan (it will handle calling Cloud Function if configured)
  return await startScan({ projectId: project.id, domain: project.domain });
}
