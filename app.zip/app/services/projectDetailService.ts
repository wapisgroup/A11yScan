import { callServerFunction } from "@/services/serverService";

type ServerResult<T = unknown> = T;

function toErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}

export async function startSitemap(projectId: string): Promise<ServerResult> {
  if (!projectId) throw new Error("projectId is required");

  try {
    return await callServerFunction("startSitemap", { projectId });
  } catch (err: unknown) {
    // eslint-disable-next-line no-console
    console.error(err);
    throw new Error("Failed to start sitemap: " + toErrorMessage(err));
  }
}

export async function startPageCollection(projectId: string): Promise<ServerResult> {
  if (!projectId) throw new Error("projectId is required");

  try {
    return await callServerFunction("startPageCollection", { projectId });
  } catch (err: unknown) {
    // eslint-disable-next-line no-console
    console.error(err);
    throw new Error("Failed to start page collection: " + toErrorMessage(err));
  }
}

export async function startFullScan(projectId: string): Promise<ServerResult> {
  if (!projectId) throw new Error("projectId is required");

  try {
    return await callServerFunction("startScan", { projectId, type: "full-scan" });
  } catch (err: unknown) {
    // eslint-disable-next-line no-console
    console.error(err);
    throw new Error("Failed to start scan: " + toErrorMessage(err));
  }
}

export type PageLike = {
  id: string;
};

export async function scanSinglePage(projectId: string, page: PageLike): Promise<ServerResult> {
  if (!projectId) throw new Error("projectId is required");
  if (!page?.id) throw new Error("page.id is required");

  try {
    // NOTE: Keeping the payload key as-is (pagesIds) to match your existing backend.
    return await callServerFunction("scanPage", { projectId, pagesIds: [page.id] });
  } catch (err: unknown) {
    // eslint-disable-next-line no-console
    console.error(err);
    throw new Error("Failed to scan page: " + toErrorMessage(err));
  }
}