export const startTrial = () => window.location.href = '/signup'
export const openSample = () => window.open('/sample-report', '_blank')
export const contactSales = () => window.location.href = 'mailto:sales@a11yscan.example?subject=Demo%20request%20for%20A11yScan'

