import { RunDoc } from "@/state-services/project-detail-states";

export const normalizeStatus = (s: unknown): string  =>{
  const v = String(s ?? "").toLowerCase().trim();
  return v || "discovered";
}

export const safeNumber = (n: unknown): number => {
  const v = Number(n);
  return Number.isFinite(v) ? v : 0;
}

export const statusFromRun = (run: RunDoc | null): string => {
  if (!run) return "discovered";
  const s = normalizeStatus(run.status);
  if (["queued", "running", "pending"].includes(s)) return "queued";
  if (["done", "finished", "completed", "success"].includes(s)) return "scanned";
  return s || "discovered";
}